#!/usr/bin/env python3
"""
unformat-paste: A cross-platform CLI tool to override Ctrl+V and paste unformatted text.

Features:
- Runs in the background as a daemon.
- Overrides Ctrl+V to paste unformatted text system-wide.
- Cross-platform (Linux, macOS, Windows).
- Graceful shutdown with Ctrl+C.

Usage:
    python3 unformat_paste.py
"""

import sys
import time
import pyperclip
import keyboard

class UnformatPaste:
    def __init__(self):
        self.running = False

    def on_activate(self, e):
        """Override Ctrl+V to paste unformatted text."""
        try:
            # Get clipboard content
            clipboard_content = pyperclip.paste()
            if clipboard_content:
                # Paste as unformatted text
                pyperclip.copy(clipboard_content)
                # Simulate Ctrl+V to paste
                keyboard.send('ctrl+v')
        except Exception as e:
            print(f"Error: {e}")

    def start(self):
        """Start the keyboard listener."""
        self.running = True
        # Override Ctrl+V
        keyboard.add_hotkey('ctrl+v', self.on_activate)
        print("unformat-paste is running. Press Ctrl+C to stop.")
        while self.running:
            time.sleep(1)

    def stop(self):
        """Stop the keyboard listener."""
        self.running = False
        keyboard.unhook_all_hotkeys()

if __name__ == "__main__":
    app = UnformatPaste()
    try:
        app.start()
    except KeyboardInterrupt:
        print("\nStopping unformat-paste...")
        app.stop()
        sys.exit(0)